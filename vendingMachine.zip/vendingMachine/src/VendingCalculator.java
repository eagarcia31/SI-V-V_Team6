public class VendingCalculator implements calculator{

    @Override
    public double calculateTotal(coinChange enteredCoins) {
        return enteredCoins.getTotal();
    }

    @Override
    public coinChange calculateChange(double amountMoneyToReturn) {
        coinChange change = new coinChange(new int[3]);
        double remainingAmount = amountMoneyToReturn;

        change.fiveDollarBill = (int) (remainingAmount / 5.00);
        change.oneDollarBill = (int) (remainingAmount / 1.00);
        change.Quarters = (int) (remainingAmount/0.25);
        return change;
    }
}
