public interface calculator {
    //create coin bundle class
    double calculateTotal(coinChange enteredCoins);
    coinChange calculateChange(double amountMoneyToReturn);

}
