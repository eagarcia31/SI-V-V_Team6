public class VendingMachineClass implements VendingMachine{

    private int selectedItem;
    private coinChange change;
    @Override
    public void displayItems() {
        System.out.println(" ________________________________");
        System.out.println("| Hello, Please Make A Selection |");
        System.out.println("|--------------------------------|");
        System.out.println("|       Available Products:      |");
        System.out.println("|   Coffee      - $2.75   [1]    |");
        System.out.println("|   Hot Cheetos - $1.75   [2]    |");
        System.out.println("|   Doritos     - $1.50   [3]    |");
        System.out.println("|   Ruffles     - $1.50   [4]    |");
        System.out.println("|   Pepsi       - $1.25   [5]    |");
        System.out.println("|   Payday      - $1.00   [6]    |");
        System.out.println("|   Snickers    - $0.75   [7]    |");
        System.out.println("|   Kit-Kat     - $0.50   [8]    |");
        System.out.println("|________________________________|");

// More efficient display but less appealing
//        for (Item item: Item.values()){
//            System.out.println("        " + item.getID() + " " + item.name() + " - Price: " + item.getPrice());
//        }
//            System.out.println("                                ");
//            System.out.println("Please Select Your Product: ");
    }

    @Override
    public void selectedItem(int item) {
        this.selectedItem = item;
    }

    @Override
    public void displayInsertCoinsMessage() {
        System.out.println("Please Enter The Number of Coins or Bills you would like to deposit");
        System.out.println("For example:");
        System.out.println("Quarters, $1 Bills, $5 Bills");
        System.out.println("   2    ,     1   ,     0   ");
        System.out.println("This would total $1.50 since only 2 Quarters and one $1 bill are being deposited.");
        System.out.println("                    ");
        System.out.println("Please enter the coins/bills");
    }

    @Override
    public void enterCoins(int... coins) {
    VendingCalculator calculator = new VendingCalculator();
    Item item = Item.value(this.selectedItem);
    double total = calculator.calculateTotal(new coinChange(coins));

    double changeAmount = total - item.getPrice();
    this.change = calculator.calculateChange(changeAmount);
    }

    @Override
    public void displayChangeMessage() {
        System.out.println("                    ");
        System.out.println("Your change is: $" + change.getTotal());
        System.out.println("$5 bills: " + change.fiveDollarBill);
        System.out.println("$1 bills: " + change.oneDollarBill);
        System.out.println("$0.25 Quarters: " + change.Quarters);
        System.out.println("Thank you for your purchase, Have a wonderful day :)");
    }

}
