public class coinChange {
    public int Quarters;
    public int oneDollarBill;
    public int fiveDollarBill;

    public coinChange(int... coinsDeposited){
        this.Quarters = coinsDeposited[0];
        this.oneDollarBill = coinsDeposited[1];
        this.fiveDollarBill = coinsDeposited[2];
    }

    public double getTotal(){
        double total = 0.0;
        total = total + this.fiveDollarBill * 5.0;
        total = total + this.oneDollarBill * 1.00;
        total = total + this.Quarters * 0.25;
        return total;
    }
}
