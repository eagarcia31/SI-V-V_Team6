public enum coinValue{
Quarters(0.25), OneDollarBill(1.00), fiveDollarBill(5.00);

private double value;
private coinValue(double value){
    this.value = value;
}
    public double getValue() {
        return value;
    }

    public static int[] parseCoins(String coins){
    String [] numberCoinsInText = coins.split(",");
    int[] result = new int[numberCoinsInText.length];

    for (int index = 0; index< numberCoinsInText.length; index++){
        result[index] = Integer.parseInt(numberCoinsInText[index]);
    }
    return result;
    }
}