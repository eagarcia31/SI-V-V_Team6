// Created by Mario Ojeda
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner userSelection = new Scanner(System.in);
        VendingMachine vendingMachine = new VendingMachineClass();

        vendingMachine.displayItems();

        while (true) {
            System.out.println("Enter selection number: ");
            String selection = userSelection.nextLine();
            try {
                int selectItemNumber = Integer.parseInt(selection);
                if (selectItemNumber < 1 || selectItemNumber > 8) {
                    System.out.println("Please make a valid selection >:(");

                } else {
                    vendingMachine.selectedItem(selectItemNumber);

                    vendingMachine.displayInsertCoinsMessage();
                    String userEnteredCoins = userSelection.nextLine();

                    while (!userEnteredCoins.matches("^[0-9]+(,[0-9]+)*$")) {
                        System.out.println("Please enter a valid input: ");
                        userEnteredCoins = userSelection.nextLine();
                    }

                    int[] enteredCoins = coinValue.parseCoins(userEnteredCoins);

                    vendingMachine.enterCoins(enteredCoins);
                    vendingMachine.displayChangeMessage();
                    break;
                }
            } catch (NumberFormatException e){
                System.out.println("Don't piss me off! make a valid selection >:O");
            }
        }
    }
}