public enum Item {
    Coffee(1,2.75), HotCheetos(2,1.75),
    Doritos(3,1.50), Ruffles(4,1.50),
    Pepsi(5,1.25), Payday(6,1.00),
    Snickers(7, 0.75), KitKat(8,0.50);
    private int ID;
    private double price;

    Item (int ID, double price){
        this.ID = ID;
        this.price = price;
    }

    public int getID(){
        return this.ID;
    }
    public double getPrice(){
        return this.price;
    }
public static Item value(int itemSelected){
        for(Item item: Item.values()){
            if (itemSelected==(item.getID())){
                return item;
            }
        }
        return null;
}
}