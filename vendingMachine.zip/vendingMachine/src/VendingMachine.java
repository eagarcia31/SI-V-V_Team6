public interface VendingMachine {
    void displayItems();

    void displayInsertCoinsMessage();
    void selectedItem(int item);
    void enterCoins(int... coins);
    void displayChangeMessage();
}
